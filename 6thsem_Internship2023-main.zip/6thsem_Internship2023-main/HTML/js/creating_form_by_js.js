let p1=document.createElement("p");
 p1.innerHTML="Hello";

 document.body.append(p1)


 let p2=document.getElementById("pa");

 p2.innerHTML="Hello";

 document.body.append(p2)